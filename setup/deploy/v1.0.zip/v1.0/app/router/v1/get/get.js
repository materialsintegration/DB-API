// import library
const express = require('express');
const router = express.Router();
const json2csv = require('json2csv');

const mid_db_path = '../../../db';
const dblist = require(mid_db_path + '/dic_dblist.js');

// get /dbabi/v[n]/get/:table
router.use(require("../logger.js"));
router.get('/', function(req, res) {
    var query = req.query;

    // check query param
    var db = '';
    if (query['db']) {
        db = req.query.db;
    }
    var table = '';
    if (query['table']) {
        table = req.query.table;
    }
    var mimetype = 'json';
    if (query['mimetype']) {
        mimetype = req.query.mimetype;
    }
    var sql = '';
    if (query['sql']) {
        sql = req.query.sql;
    }

    // get connection
    var dbobj = null;
    dblist.forEach(function( d ) {
        if (db != d.name) return

        switch (d.dbtype) {
            case 'mysql':
                var Mysql = require(mid_db_path + '/' + d.middle)
                dbobj = new Mysql(d.name)

                break
            case 'postgresql':
                var Postgresql = require(mid_db_path + '/' + d.middle)
                dbobj = new Postgresql(d.name)

                break
            default:
                console.log('no database type match')
                return

                break
        }
    }); 
    
    // execute sql
    if (sql != '') {
        try {
            dbobj.getRecordset(sql, function(flds, result) {
                // output
                var output = '';
                if (mimetype == 'json') {
                    output = result;
                    res.setHeader('Content-Type', 'application/json');
                } else if (mimetype == 'csv') {
                    output = json2csv.parse(result, flds);
                    res.setHeader('Content-Type', 'text/csv; charset=UTF-8');
                }

                res.send(output);
            })

        } catch (error) {
            console.log('error has occured');
            console.log(error.message);

            res.send('');
        }
    } else {
        res.send('');
    }
});

module.exports = router;

