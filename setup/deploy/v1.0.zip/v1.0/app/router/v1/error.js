
const logErrors = (err, req, res, next) => {
    var moment = require('moment');

    var ipaddress = req.headers["x-forwarded-for"] ||
        req.connection.remoteAddress ||
        (req.socket && req.socket.remoteAddress) ||
        (req.connection.socket && req.connection.socket.remoteAddress) ||
        "0.0.0.0";
    var dt = moment();
    // var date = (new Date()).toISOString();
    var date = dt.format('YYYY/MM/DD hh:mm:ss');
    var method = req.method;
    var url = req.url;
    var ua = req.headers['user-agent']; 
    var e = err.stack;

    console.log(`${ipaddress} [${date}] "${method} ${url}" - ${ua} : ${e}` );
    next(err);
}

const errorHandler = (err, req, res, next) => {
    var boom = require('@hapi/boom');
    if (res.headersSent) return next(err)
    if (!err.statusCode) err = boom.boomify(err)

    if (err.isServer) {
        // boom通した500番台のエラーはisServerでtrueが返るので
        // 500番台のみsentryみたいなエラー監視saasに送信したりできる
        return res.status(err.statusCode).json(err)
    }
    return err.isBoom
      ? res.status(err.output.statusCode).json(err.output.payload)
      : res.status(err.statusCode).json(err)
}

//export default errorHandler
module.exports = logErrors;
module.exports = errorHandler;
