// ----------------------------
// import library
// ----------------------------
var express    = require('express');
var app        = express();
var bodyParser = require('body-parser');
var log4js     = require('log4js');

// ----------------------------
// local variable
// ----------------------------
const rooturl = '/db-api/v1/get';

// body-parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// port
var port = process.env.PORT || 3300;

// routing
const router_get_path = './router/v1/get'
// var route_get  = require(router_get_path + '/get.js');
// app.use(rooturl, route_get);

// common
var getcommon = require(router_get_path + '/get.js');

// ----------------------------
// local function
// ----------------------------

// ----------------------------
// main
// ----------------------------

// log setting
log4js.configure(process.cwd() + '/config/log4js.config.json');
const systemLogger = log4js.getLogger('system');
const httpLogger   = log4js.getLogger('http');
const accessLogger = log4js.getLogger('access');

app.use(log4js.connectLogger(accessLogger));
app.use((req, res, next) => {
    if (typeof req === 'undefined' || req === null ||
        typeof req.method === 'undefined' || req.method === null ||
        typeof req.header === 'undefined' || req.header === null) {
        next();
        return;
    }
    if (req.method === 'GET') {
        httpLogger.info(req.query);
    } else {
        httpLogger.info(req.body);
    }
    next();
});
systemLogger.info("nodejs app start");

// define middleware


// routing
app.use(rooturl + '/', getcommon);

// logger
//const systemLogger = require('./lib/log/systemLogger');
//app.use(systemLogger());

// server
// timeout: 60 min
//app.listen(port);
//console.log('listen on port ' + port);
var app_server = app.listen(port);
app_server.timeout = 1000 * 60 * 60;

console.log('listen on port ' + port);



