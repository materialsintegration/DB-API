
// module load
const mysql = require('mysql');

const confs = {
    'NIMS_material' :
    {
        host      : 'xx.xx.xx.xx',
        user      : 'hogehoge',
        password  : '',
        database  : 'material',
        connectionTimeout : 10000, // timeout(msec)
        supportBigNumbers : true, // support bigint, decimal
        connectionLimit : 20, // conn instance number at a time
        removeNodeErrorCount: 3 // retry count
    }
};


class Mysql {

    constructor(dbname) {
        this.dbname = dbname;

        // get conf
        var conf = null;
        if (this.dbname in confs) {
            this.conf = confs[this.dbname];
        }
    };

    getRecordset(sql, callback) {
        try {
            var pool = mysql.createPool(this.conf)
            pool.getConnection( (err, connection) => {
                if (err) throw err

                connection.query(sql, (err, results, fields) => {
                    if (err) throw err

                    // field list
                    var flds = [];
                    fields.forEach( (field) => {
                        flds.push(field.name)
                    });

                    callback(flds, results)
                })
                pool.end()
            })
        } catch (error) {
            console.log(error.message)

            callback(null, null)
        }
    };
}

module.exports = Mysql;
