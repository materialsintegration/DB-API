
// module load
const { Pool } = require('pg');

const confs = {
    'NIMS_material' : 
    {
        host      : 'xx.xx.xx.xx',
        database  : 'db',
        user      : 'hogehoge',
        password  : 'hogehoge',
        port      : 5432,
        max       : 20, // conn instance number at a time
        idleTimeoutMillis : 30000, // idle timeout (millisec)
        connectionTimeoutMillis : 2000, // connection timeout (millisec)
    }
};

class Postgresql {

    constructor(dbname) {
        this.dbname = dbname;

        // get conf
        var conf = null;
        if (this.dbname in confs) {
            this.conf = confs[this.dbname];
        }
    };

    getConnection(callback) {
        this.pool.connect( (err, client) => {
            if (err) {
                console.log(err.message)
                callback(err, null)
            } else {
                console.log('connected.')
                callback(null, client)
            }
        })
    };

    getRecordset(sql, callback) {
        try {
            var pool = new Pool(this.conf)
            pool.query(sql, (err, result) => {
                if (err) throw err

                // field list
                var flds = []
                result.fields.forEach( (field) => {
                    flds.push(field.name)
                })
                   
                callback(flds, result.rows)
            })
            pool.end()
        } catch (error) {
            console.log(error.message)

            callback(null, null)
        }
    };
}

//exports.postgres = postgres;
module.exports = Postgresql;
