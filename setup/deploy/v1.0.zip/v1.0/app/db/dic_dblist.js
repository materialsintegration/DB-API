
const dblist = [
    {
        name : 'NIMS_material',
        dbtype : 'mysql',
        middle : 'Mysql.js'
    },
    {
        name : 'GRANTA',
        dbtype : 'granta',
        middle : 'confDB_granta.js'
    },
];

module.exports = dblist;

